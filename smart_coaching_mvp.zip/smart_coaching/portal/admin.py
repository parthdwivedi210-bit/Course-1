from django.contrib import admin
from .models import *
admin.site.register([Institute, Membership, Batch, Student, ParentLink, Attendance, FeeRecord, Test, Mark, SyllabusTopic])
