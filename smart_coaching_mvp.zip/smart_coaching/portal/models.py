from django.conf import settings
from django.db import models
from django.utils import timezone

class Institute(models.Model):
    name = models.CharField(max_length=180)
    slug = models.SlugField(unique=True)
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=20, blank=True)
    city = models.CharField(max_length=80, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    active = models.BooleanField(default=True)
    def __str__(self): return self.name

class Membership(models.Model):
    ADMIN, TEACHER, PARENT, STUDENT = "admin", "teacher", "parent", "student"
    ROLES = [(ADMIN,"Admin"),(TEACHER,"Teacher"),(PARENT,"Parent"),(STUDENT,"Student")]
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE, related_name="memberships")
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    role = models.CharField(max_length=12, choices=ROLES)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["institute","user"], name="unique_institute_member")]
    def __str__(self): return f"{self.user} · {self.institute} · {self.role}"

class Batch(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    course_name = models.CharField(max_length=120, blank=True)
    academic_year = models.CharField(max_length=20, blank=True)
    def __str__(self): return self.name

class Student(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    batch = models.ForeignKey(Batch, on_delete=models.SET_NULL, null=True, blank=True)
    admission_no = models.CharField(max_length=40)
    full_name = models.CharField(max_length=160)
    date_of_birth = models.DateField(null=True, blank=True)
    guardian_name = models.CharField(max_length=160, blank=True)
    guardian_phone = models.CharField(max_length=20, blank=True)
    joined_on = models.DateField(default=timezone.localdate)
    active = models.BooleanField(default=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["institute","admission_no"], name="unique_admission_per_institute")]
        ordering = ["full_name"]
    def __str__(self): return self.full_name

class ParentLink(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    parent = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["parent","student"], name="unique_parent_student_link")]

class Attendance(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    date = models.DateField(default=timezone.localdate)
    present = models.BooleanField(default=True)
    marked_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["student","date"], name="one_attendance_per_day")]

class FeeRecord(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    title = models.CharField(max_length=100, default="Tuition fee")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    due_date = models.DateField(null=True, blank=True)
    paid_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    paid_on = models.DateField(null=True, blank=True)
    note = models.CharField(max_length=240, blank=True)
    @property
    def balance(self): return self.amount - self.paid_amount

class Test(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    batch = models.ForeignKey(Batch, on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=160)
    subject = models.CharField(max_length=80)
    held_on = models.DateField(default=timezone.localdate)
    max_marks = models.PositiveIntegerField(default=100)
    topic = models.CharField(max_length=160, blank=True)
    class Meta: ordering = ["-held_on"]

class Mark(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    test = models.ForeignKey(Test, on_delete=models.CASCADE)
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    marks_obtained = models.DecimalField(max_digits=7, decimal_places=2)
    remarks = models.CharField(max_length=240, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=["test","student"], name="one_mark_per_student_test")]

class SyllabusTopic(models.Model):
    institute = models.ForeignKey(Institute, on_delete=models.CASCADE)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE)
    subject = models.CharField(max_length=80)
    chapter = models.CharField(max_length=160)
    completed = models.BooleanField(default=False)
    completed_on = models.DateField(null=True, blank=True)
    order = models.PositiveIntegerField(default=0)
    class Meta: ordering = ["subject","order","chapter"]
