from decimal import Decimal
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Avg
from django.shortcuts import render, redirect
from django.utils import timezone
from .models import Student, Attendance, FeeRecord, Test, Mark, SyllabusTopic, ParentLink

@login_required
def dashboard(request):
    membership = request.membership
    if not membership:
        return render(request, "portal/no_institute.html")
    institute = membership.institute
    role = membership.role
    if role == "parent":
        linked = ParentLink.objects.filter(institute=institute, parent=request.user).select_related("student")
        students = [x.student for x in linked]
    elif role == "student":
        students = list(Student.objects.filter(institute=institute, admission_no=request.user.username))
    else:
        students = Student.objects.filter(institute=institute, active=True)
    if role in ("parent", "student"):
        student_ids = [s.id for s in students]
        attendance_qs = Attendance.objects.filter(institute=institute, student_id__in=student_ids)
        fee_qs = FeeRecord.objects.filter(institute=institute, student_id__in=student_ids)
        marks_qs = Mark.objects.filter(institute=institute, student_id__in=student_ids).select_related("test","student")
        context_students = students
    else:
        attendance_qs = Attendance.objects.filter(institute=institute, date=timezone.localdate())
        fee_qs = FeeRecord.objects.filter(institute=institute)
        marks_qs = Mark.objects.filter(institute=institute).select_related("test","student")
        context_students = students
    total_students = len(context_students) if isinstance(context_students, list) else context_students.count()
    present_today = attendance_qs.filter(date=timezone.localdate(), present=True).count() if role not in ("parent","student") else attendance_qs.filter(present=True).count()
    fee_balance = fee_qs.aggregate(total=Sum("amount"), paid=Sum("paid_amount"))
    pending = (fee_balance["total"] or Decimal("0")) - (fee_balance["paid"] or Decimal("0"))
    recent_marks = marks_qs.order_by("-test__held_on")[:8]
    topics = SyllabusTopic.objects.filter(institute=institute)
    context = {
        "institute": institute, "role": role, "students": context_students,
        "total_students": total_students, "present_today": present_today,
        "pending_fees": pending, "recent_marks": recent_marks,
        "completed_topics": topics.filter(completed=True).count(),
        "total_topics": topics.count(),
    }
    return render(request, "portal/dashboard.html", context)
