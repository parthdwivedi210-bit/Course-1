from .models import Membership
class InstituteContextMiddleware:
    # Institute selection is explicit in the session; every view still scopes its own querysets.
    def __init__(self, get_response): self.get_response = get_response
    def __call__(self, request):
        request.membership = None
        if request.user.is_authenticated:
            institute_id = request.session.get("active_institute_id")
            if institute_id:
                request.membership = Membership.objects.filter(
                    user=request.user, institute_id=institute_id, institute__active=True
                ).select_related("institute").first()
            if request.membership is None:
                request.membership = Membership.objects.filter(
                    user=request.user, institute__active=True
                ).select_related("institute").first()
                if request.membership:
                    request.session["active_institute_id"] = request.membership.institute_id
        return self.get_response(request)
