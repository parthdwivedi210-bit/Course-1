# Smart Coaching — multi-institute management platform

A Django starter MVP for coaching institutes. It includes institute, membership/role, batch, student, parent link, attendance, fee, test, marks and syllabus data models; login; a premium responsive dashboard; and Django Admin for initial record management.

## Run locally

1. Install Python 3.11+.
2. Create and activate a virtual environment.
3. Install dependencies: `pip install -r requirements.txt`
4. Copy `.env.example` to `.env` and set a private `DJANGO_SECRET_KEY`.
5. Run migrations: `python manage.py makemigrations portal` then `python manage.py migrate`
6. Create an admin login: `python manage.py createsuperuser`
7. Start: `python manage.py runserver`
8. Open `http://127.0.0.1:8000/`

## First-time setup

1. Sign in at `/admin/`.
2. Create an Institute.
3. Create a Membership linking your login to that institute with role `admin`.
4. Create batches and students; use the same institute on each record.
5. Add attendance, fee records, tests, marks and syllabus topics.
6. Create parent accounts and ParentLink records to grant access to a specific child.

## Multi-tenant security model

This starter uses shared database tables with an `institute_id` foreign key on institute-owned records. The dashboard scopes its queries to the signed-in user's active institute, and parent dashboards use explicit ParentLink records. This is a foundation, not a complete production security review. Before real institutes use it, implement and test institute-scoped CRUD views/API permissions for every model, audit logging, automated tenant-isolation tests, password reset/email verification, rate limiting, backups, HTTPS, and production secrets. Never expose Django Admin to ordinary parent/student accounts in production.

## Planned next modules

Teacher workload and salary, timetable, assignments/resources, parent notifications, PDF report cards, CSV imports/exports, online payments, branch management, analytics, and institute subscription/billing.

## Production notes

Use PostgreSQL, HTTPS, `DEBUG=False`, a strong secret key from environment variables, restricted `ALLOWED_HOSTS`, secure cookies, scheduled backups, and a managed deployment. Do not put real student data into a demo deployment.
